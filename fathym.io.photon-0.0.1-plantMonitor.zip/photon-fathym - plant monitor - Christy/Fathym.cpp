#include "Fathym.h"
#include "math.h"

// Handler that receives MQTT messages for this device
Fathym * instance = NULL;

void mqttReceiveHandler(char * topic, byte * payload, unsigned int length) {
  if (instance != NULL) {
      instance->receive(topic, payload, length);
  }
}


// Device refresh routine that runs on a software timer
/*void refreshHandler(void) {
  if (instance == NULL) return;

  instance->_brightness = fabsf(sinf(millis() / 250.0));
  uint16_t v = (uint16_t)(instance->_brightness * 255.0);
  if (getPinMode(A5) != OUTPUT) pinMode(A5, OUTPUT);
  analogWrite(A5, v);
}

Timer refresh(33, refreshHandler);*/

// Constructor
Fathym::Fathym() {
  instance = this;

  // HTTP POST URL & PORT
  _httpHost = String(HTTP_HOST);
  _httpUrl = String(HTTP_URL);
  _httpPort = HTTP_PORT;

  // MQTT Connection
  _mqttServer = MQTT_SERVER;
  _mqttPort = MQTT_PORT;
  _mqttUsername = MQTT_USERNAME;
  _mqttPassword = MQTT_PASSWORD;
  _lastTimeSync = 0;
  _mqttKeepAlive = MQTT_KEEPALIVE;
  _subscribed = false;
  _error = ERROR_NONE;

  // Setup status LEDs
  if (FATHYM_LED_STATUS) {
    // General status
    pinMode(FATHYM_STATUS_LED_PIN, OUTPUT);

    // Publish status
    if (getPinMode(FATHYM_PUBLISH_LED_PIN) != OUTPUT) {
      pinMode(FATHYM_PUBLISH_LED_PIN, OUTPUT);
    }

    // Receive status
    /*if (getPinMode(FATHYM_RECEIVE_LED_PIN) != OUTPUT) {
      pinMode(FATHYM_RECEIVE_LED_PIN, OUTPUT);
    }*/
  }

  // Set the RGB LED brightness
  RGB.brightness(FATHYM_LED_BRIGHTNESS);

  // Publishing rate
  setPublishRate(FATHYM_PUBLISH_RATE); // this makes sure the keep alive is greater than publish rate

    // Setup internal JSON buffer
  _json = &_jsonBuffer.createObject();
  JsonObject & json = *_json;

  // Assign the Photon's device ID for the ID in published messages
  _id = System.deviceID();
  json[FATHYM_ID_PROPERTY] = _id.c_str();

  // Set the send/receive/publish topics using the device ID
  _sendTopic = String("fathym.devices.from.") + MQTT_MESSAGE_GROUP + "." + _id;
  _receiveTopic = String("fathym.devices.to.") + MQTT_MESSAGE_GROUP + "." + _id;
  _publishTopic = String("fathym.devices.pub.") + MQTT_MESSAGE_GROUP + "." + _id;

  // If adding a time stamp, setup time zone
  if (FATHYM_ADD_TIMESTAMP) {
    Time.zone(FATHYM_TIMEZONE_OFFSET);
    time_t time = Time.now();
    _timeStamp = Time.format(time, TIME_FORMAT_ISO8601_FULL);
  }

  // If configured to add the device's name make an entry into the message
  if (FATHYM_ADD_DEVICE_NAME) {
    json[FATHYM_DEVICE_NAME_PROPERTY] = _name.c_str();
    _name = NULL;
  }

  // Initialize storage
  _flash = Devices::createDefaultStore();
}

// Handler that retrieves the device's name from the cloud
void Fathym::nameHandler(const char * topic, const char * data) {
  _name = String(data);
}

// Starts the Fathym library (should be called in setup() function of your main project file)
void Fathym::setup(void) {
  // Read to make sure the configuration system has been created in flash on this board
  uint8_t cfLength = strlen(FATHYM_CONFIG_FLAG) + 1;
  char initFlag[cfLength];
  _flash->read(initFlag, FATHYM_CONFIG_ADDRESS, cfLength);

  // Define various address offsets for different values of the configuration system
  uint32_t configLengthAddress = FATHYM_CONFIG_ADDRESS + cfLength;
  uint32_t configJsonAddress = configLengthAddress + 2;

  // Prepare to load in the length of the bytes of the JSON configuration string to read and parse
  uint16_t configJsonLength = 0;

  // If the configuration area has not been formatted/initialized, do so
  if (String(initFlag) != FATHYM_CONFIG_FLAG) {
    _flash->writeString(FATHYM_CONFIG_FLAG, FATHYM_CONFIG_ADDRESS);
    _flash->write(configJsonLength, configLengthAddress);
    Serial.println("Fathym config system formatted");
  }
  // Otherwise if the system is configured, read in the string length
  else {
      _flash->read(configJsonLength, configLengthAddress);
  }

  // If there is no configuration data saved, create a new config object
  if (configJsonLength == 0) {
    Serial.println("No device config found");
    _config = &_configBuffer.createObject();
  }
  // Otherwise parse and load configuration values
  else {
    char configJson[configJsonLength];
    _flash->read(configJson, configJsonAddress, configJsonLength);
    _configJson = String(configJson);
    Serial.println(_configJson);

    // Parse the config values
    _config = &_configBuffer.parseObject((char *)_configJson.c_str());
    JsonObject & config = *_config;

    // If the JSON config data was bad, reset configuration string
    if (!config.success()) {
      Serial.println("Bad config data; config removed");
        _flash->write((uint16_t)0, configLengthAddress);
        System.reset(); // restart to restore to a valid config object
    }
    else {
      Serial.println("Device config loaded");
      applyConfig(config, false); // apply but don't save since it was just loaded
    }
  }

  // If configured to use batteries, set it up
  #ifdef FATHYM_USE_BATTERY_POWER
  lipo.begin(); // start up the battery monitor
  lipo.quickStart(); // recalibrate for battery SoC
  #endif

  // Start refresh timer
  //refresh.start();

  // Connect to AMQP broker via underlying MQTT layer/plugin
  connect(_mqttServer, _mqttUsername, _mqttPassword);
}

// Begins a Fathym message update cycle; performs connection maintenance and prepares the connection for publishing.
void Fathym::beginUpdate(void) {
  // If the error state exists is non-critical, clear it
  if (_error != ERROR_NONE && _error < ERROR_CRITICAL) {
    _error = ERROR_NONE;
  }

  // Get the current device uptime
  unsigned long uptime = millis();

  // Record the time at which the update began
  _lastBeginUpdate = uptime;

  // If it is time to resync device time to cloud network time, do so...
  if ((uptime - _lastTimeSync) / 60000 >= FATHYM_RESYNC_TIME_MINS) {
    Particle.syncTime();
    _lastTimeSync = uptime;
  }

  // If we're using the device name, but don't have it yet, attempt to retrive the name
  if (FATHYM_ADD_DEVICE_NAME && _name == NULL) {
    while (_name == NULL) {
      flash(3, 33);
      // Subscribe to receive device name from Particle cloud
      Particle.subscribe("spark/", &Fathym::nameHandler, this);
      Particle.publish("spark/device/name");
      delay(2000); // wait a little bit to receive the name
    }
  }

  // If connected, update the underlying MQTT client message processing
  if (isConnected()) {
    // Subscribe to receive messages
    subscribe();
  }
  // Otherwise attempt to reconnect
  else {
    reconnect(true);
  }
}

// Ends a Fathym message update cycle.
void Fathym::endUpdate(void) {
  if (FATHYM_AUTO_PUBLISH) {
    // Publish the current message data
    bool published = publish();

    // If publishing failed, don't execute the rest of the end update sequence
    if (!published) {
      Serial.println("failed to publish");
      return;
    }

    // Start with the ideal update delay in milliseconds
    unsigned long updateDelay = _publishRate * 1000; // convert from seconds to milliseconds

    // Get current time
    unsigned long now = millis();

    // Get the delta time between the beginning of the update and now
    long deltaTime = now - _lastBeginUpdate;

    // Adjust the ideal delay by the delta time compensated amount
    updateDelay -= deltaTime;
    if (updateDelay < 0) updateDelay = 0;

    // Set the target time to delay until before next publish
    unsigned long targetTime = now + updateDelay;
    unsigned long lastTime = now;

    // If config settings have changed, don't delay just republish with new values
    if (_configChanged) {
      // Update MQTT communications
      int mqttMsgPerUpdate = MQTT_MESSAGES_PER_UPDATE;
      if (mqttMsgPerUpdate < 0) mqttMsgPerUpdate = 1; // make sure there is a positive number

      // Update communications and consume messages
      for (int i = 0; i < mqttMsgPerUpdate; i++) {
          _mqtt->loop();
      }

      // Reset flag
      _configChanged = false;

      return;
    }

    // Check power/sleep requirements
    bool isSleeping = false; // assume no power savings strategy

    // If a power saving mode is active, setup sleep parameters
    if (FATHYM_POWER_MODE != FATHYM_POWER_MODE_ALWAYS_ON) {
      // Check to see if it is worth sleeping
      int sleepTime = updateDelay/1000 - FATHYM_SLEEP_WAKE_OFFSET;
      isSleeping = sleepTime > 10;

      // If so, select the correct strategy
      if (isSleeping) {
        // WiFi sleep mode
        if (FATHYM_POWER_MODE == FATHYM_POWER_MODE_WIFI_SLEEP) {
            System.sleep(sleepTime);
        }
        // Deep sleep mode
        else if (FATHYM_POWER_MODE == FATHYM_POWER_MODE_DEEP_SLEEP) {
          System.sleep(SLEEP_MODE_DEEP, sleepTime);
        }
      }
    }

    // Wait until the next publish time but split it into chunks
    // so MQTT communications can update throughout.
    while (lastTime <= targetTime) {
      // Update MQTT communications
      int mqttMsgPerUpdate = MQTT_MESSAGES_PER_UPDATE;
      if (mqttMsgPerUpdate < 0) mqttMsgPerUpdate = 1; // make sure there is a positive number

      // If WiFi was sleeping but is now ready, reconnect
      if (isSleeping && WiFi.ready() && !isConnected()) reconnect(false);

      // Update communications and consume messages
      for (int i = 0; i < mqttMsgPerUpdate; i++) {
          _mqtt->loop();
      }

      // If the configuration has changed, abandon the delay
      if (_configChanged) {
        // Reset flag
        _configChanged = false;
        return;
      }

      // Get the current time
      now = millis();

      // Use whichever delay has the smallest increment
      long mqttUpdateRate = MQTT_UPDATE_RATE;
      if (mqttUpdateRate < 0) mqttUpdateRate = 1000; // make sure there is a positive update rate and if not, default to 1 second
      long pubDelay = updateDelay < mqttUpdateRate ? updateDelay : mqttUpdateRate;

      // Compensate for overdelay past the target delay time
      unsigned long nextTime = now + pubDelay;

      // If the time target given the next delay time overshoots...
      if (nextTime > targetTime) {
        // Substract by the overage to even it back out
        pubDelay -= nextTime - targetTime;
        if (pubDelay < 0) pubDelay = 0;
      }

      // Delay until next loop
      if (pubDelay > 0) delay((unsigned long)pubDelay);

      // Update the last time to the current time
      lastTime = millis();
    }
  }
}

// Connects to the given message broker/server on the given port using the provided username and password.
bool Fathym::connect(char * server, char * username, char * password) {
  return connect(server, MQTT_PORT, username, password);
}

// Connects to the given message broker/server on the given port using the provided username and password.
bool Fathym::connect(char * server, uint16_t port, char * username, char * password)
{
  _mqttServer = server;
  _mqttPort = port;
  _mqttUsername = username;
  _mqttPassword = password;

  // If the MQTT client hasn't been created yet, create it
  if (_mqtt == NULL) {
    _mqtt = new MQTT(_mqttServer, _mqttPort, mqttReceiveHandler);
    _mqtt->setKeepAlive(_mqttKeepAlive);
  }

  // Connect using the MQTT client
  _mqtt->connect(_id.c_str(), _mqttUsername, _mqttPassword);

  // Check for a valid connection state and report accordingly
  if (_mqtt->isConnected()) {
    // Subscribe to receive messages
    subscribe();

    flash(4, 50);
    return true;
  }
  else {
    _subscribed = false;
    return false;
  }
}

// Reconnects to the last known connection.
bool Fathym::reconnect(bool flash) {
  _subscribed = false;
  if (flash) flashRGB(3, FATHYM_RGB_LED_DELAY, 242, 101, 34);
  return connect(_mqttServer, _mqttPort, _mqttUsername, _mqttPassword);
}

// Determines whether or not Fathym is currently connected to the configured message broker.
bool Fathym::isConnected(void) {
  if (_mqtt == NULL) return false;
  return _mqtt->isConnected();
}

// Sets the MQTT connection keep alive time in seconds
void Fathym::setKeepAlive(uint16_t seconds) {
  // No change, nothing to do
  if (_mqttKeepAlive == seconds) return;

  // Set local keep alive value
  _mqttKeepAlive = seconds;

  // Enforce a minimum value for keep alive
  if (_mqttKeepAlive < 5) _mqttKeepAlive = 5;

  // MQTT object is not initialized yet
  if (_mqtt == NULL) return;

  // Set keep alive on underlying MQTT instance
  _mqtt->setKeepAlive(_mqttKeepAlive);

  // Reconnect after keep alive update to initiate new keep alive with broker
  reconnect(false);
}

// Sets the publishing rate in seconds when auto-publishing is enabled.
void Fathym::setPublishRate(uint16_t seconds) {
  if (_publishRate == seconds) return; // no change, nothing to do

  // If the rate is set to 0, reject it and fall back to a default of 10
  if (seconds == 0) seconds = 10;

  // Update the rate
  _publishRate = seconds;

  // Make sure that the MQTT keep alive time is greater than the update cycle
  // otherwise the connection will continuously time out after one publish
  if (_mqttKeepAlive <= _publishRate) {
    setKeepAlive(_publishRate + (_publishRate / 2)); // keep alive is 1.5 times the publish rate
  }
}

// Subscribes the device to all of its message queues for listening and communication
bool Fathym::subscribe(void) {
  if (_subscribed) return true; // already subscribed

  if (!_subscribed) {
    MQTT::EMQTT_QOS qos = (MQTT::EMQTT_QOS)1; // QoS 1 for durable queues (in case device or server drops)
    _subscribed = _mqtt->subscribe(_receiveTopic, qos);
  }
}

// Publishes a raw mesage payload to the connected message broker/server on the given topic.
bool Fathym::publishRaw(const char * topic, const char * payload) {
  if (!isConnected()) {
    return false;
  }

  bool success = _mqtt->publish(topic, payload);

  // If we're using LED pin debugging and the publish was successful flash the LED to indicate a publish
  if (FATHYM_LED_STATUS && success) {
    digitalWrite(FATHYM_PUBLISH_LED_PIN, HIGH);
    delay(FATHYM_SINGLE_LED_DELAY);
    digitalWrite(FATHYM_PUBLISH_LED_PIN, LOW);
  }

  return success;
}

// Publish the current message data to the connected message broker/server
bool Fathym::publish(void) {
  return publish(_publishTopic); // publish to the default topic for the device
}

// Publish the current message data to the connected message broker/server
bool Fathym::publish(const char * topic) {
  if (!isConnected()) {
    return false;
  }

  JsonObject & json = *_json;
  const char * payload;

  // If there is no current error state, publish data
  if (_error == ERROR_NONE) {
    // If configured to add the device's cloud name, include it
    if (FATHYM_ADD_DEVICE_NAME) {
      json[FATHYM_DEVICE_NAME_PROPERTY] = _name.c_str();
    }

    // If set to include the device uptime, include it
    if (FATHYM_ADD_UPTIME) {
      json[FATHYM_UPTIME_PROPERTY] = millis();
      //set(FATHYM_UPTIME_PROPERTY, (long)millis(), "ms");
    }

    // If set to include device free memory, include it
    if (FATHYM_ADD_FREE_MEMORY) {
      json[FATHYM_FREE_MEMORY_PROPERTY] = System.freeMemory();
      //set(FATHYM_FREE_MEMORY_PROPERTY, (int)System.freeMemory(), "bytes");
    }

    // Include battery information as configured
    #ifdef FATHYM_USE_BATTERY_POWER

    if (FATHYM_USE_BATTERY_POWER && FATHYM_MONITOR_BATTERY) {
        // If set to include battery voltage, include it
        if (FATHYM_ADD_BATTERY_VOLTAGE) {
          json[FATHYM_BATTERY_VOLTAGE_PROPERTY] = lipo.getVoltage();
          //set(FATHYM_BATTERY_VOLTAGE_PROPERTY, (float)lipo.getVoltage(), "v");
        }

        // If set to include battery charge level, include it
        if (FATHYM_ADD_BATTERY_CHARGE) {
          json[FATHYM_BATTERY_CHARGE_PROPERTY] = lipo.getSOC();
          //set(FATHYM_BATTERY_CHARGE_PROPERTY, (float)lipo.getSOC(), "%");
        }
    }

    #endif // FATHYM_USE_BATTERY_POWER

    // If set to include the WIFI signal strength, add it
    if (FATHYM_ADD_RSSI) {
      json[FATHYM_RSSI_PROPERTY] = WiFi.RSSI();
    }

    // If set to use time stamp, add the current time stamp
    if (FATHYM_ADD_TIMESTAMP) {
      time_t time = Time.now();
      _timeStamp = Time.format(time, TIME_FORMAT_ISO8601_FULL);
      json[FATHYM_TIMESTAMP_PROPERTY] = _timeStamp.c_str();
    }

    // Serialize current message values
    size_t maxDataSize = MQTT_MAX_PACKET_SIZE - MQTT_MAX_HEADER_SIZE; // leave some size for the MQTT header
    char buffer[maxDataSize]; // create a buffer of the max payload size
    payload = buffer;
    size_t written = json.printTo(buffer, maxDataSize);

    // Check to see that the JSON object is properly terminated
    if (buffer[written - 1] != '}') {
      _error = ERROR_JSON_BUFFER_MAX;
    }
  }

  // If there is an error, send an error message payload instead with the error code
  if (_error != ERROR_NONE) {
    _errorJson = String("{\"" + _idProp + "\":\"" + _id + "\",\"error\":");
    _errorJson.concat(_error);
    _errorJson.concat("}");
    payload = _errorJson.c_str();
  }

  // Wait to assume a successful publish
  bool success = false;

  if (PUBLISH_PROTOCOL == "HTTP") {
    // HTTP Publish to the given HTTP endpoint
    _httpData = String(payload);
    success = httpPost(_httpData) == 1;
  }
  else if (PUBLISH_PROTOCOL == "MQTT") {
    // MQTT Publish to the given topic on the connected message broker/server
    success = _mqtt->publish(topic, payload);
  }

  // If we're using LED pin debugging show state
  if (FATHYM_LED_STATUS) {
    if (success) {
      // Flash publish success
      digitalWrite(FATHYM_PUBLISH_LED_PIN, HIGH);
      delay(FATHYM_SINGLE_LED_DELAY);
      digitalWrite(FATHYM_PUBLISH_LED_PIN, LOW);
    }
    // Otherwise indicate publish error
    else {
      flash(4, 75);
    }
  }

  return success;
}

// Sends an HTTP payload to the configured HTTP API endpoint
int Fathym::httpPost(String postData) {
  // Include basic header values
  _httpRequest = "POST " + _httpUrl + " HTTP/1.1\n";
  _httpRequest += "Host: " + _httpHost + "\n";
  _httpRequest += "User-Agent: ParticlePhoton/" + System.version() + " (Fathym Photon)\n";
  _httpRequest += "Connection: close\n";

  // Include custom header values
  #ifdef HTTP_HEADERS
  _httpRequest += HTTP_HEADERS;
  #endif

  // Include content/payload
  _httpRequest += "Content-Type: application/json\n";
  _httpRequest += "Content-Length: " + String(postData.length()) + "\n\n";
  _httpRequest += postData;

  TCPClient client;
	char response[HTTP_RESPONSE_MAX_SIZE];
	int i = 0;
	int retVal = 0;

	if (client.connect(_httpHost, _httpPort)) // Connect to the server
	{
		// Write HTTP POST to the TCP stream
		client.print(_httpRequest);
		//delay(1000);
		// Read in HTTP response
		int timeout = 1000000; // 1 second in microseconds
		while (client.available() || (timeout-- > 0))
		{
			char c = client.read();
			if (i < HTTP_RESPONSE_MAX_SIZE) response[i++] = c; // Add character to response string
			delayMicroseconds(1);
		}

    // Debug the HTTP response
    //Serial.println(response);

		// Search the response string for "200 OK", if that's found the post
		// succeeded.
		if (strstr(response, "200 OK"))
		{
			retVal = 1;
		}
		else if (strstr(response, "400 Bad Request"))
		{	// "400 Bad Request" means the Phant POST was formatted incorrectly.
			// This most commonly ocurrs because a field is either missing,
			// duplicated, or misspelled.
			retVal = -1;
		}
		else
		{
			// Otherwise we got a response we weren't looking for.
			retVal = -2;
		}
	}
	else
	{	// If the connection failed:
		retVal = -3;
	}
	client.stop();	// Close the connection to server.

  _httpRequest = "";
  _httpData = "";

	return retVal;	// Return error (or success) code.
}

// Receives an MQTT message
void Fathym::receive(char * topic, byte * payload, unsigned int length) {
  char p[length + 1];
  memcpy(p, payload, length);
  p[length] = NULL;
  DynamicJsonBuffer rxBuffer;
  JsonObject & msg = rxBuffer.parseObject(p);

  // If there was an error parsing...
  if (!msg.success()) {
    showReceiveError();
  }
  // Otherwise decode the message
  else {
    // Make sure the message declares its type
    if (!msg.containsKey("type")) {
      showReceiveError();
      return;
    }

    // Get the message type
    String type = String((const char * )msg["type"]);

    // Dispatch message by type

    // If this is a configuration values update, apply it
    if (type == "config") {
      // If the configuration values are set to be cleared, clear them
      if (msg.containsKey("clear") && (bool)msg["clear"]) {
        uint16_t configLength = 0;
        _flash->write(configLength, FATHYM_CONFIG_ADDRESS); // reset/clear saved config values
        Serial.println("Device config cleared");
      }
      else {
        // Otherwise make sure there are values to set
        if (!msg.containsKey("values")) {
          showReceiveError();
          return;
        }

        // Update the device configuration with the provided values
        bool save = msg.containsKey("save") ? (bool)msg["save"] : false;
        applyConfig((JsonObject &)msg["values"], save);
      }
    }
    // If this is a remote function...
    else if (type == "function") {
      // Ensure there is a function name
      if (!msg.containsKey("name")) {
        showReceiveError();
        return;
      }

      // Call the function
      String name = String((const char *)msg["name"]);
      String args = msg.containsKey("args") ? String((const char *)msg["args"]) : NULL;
      String retVal = callRegFunction(name, args);

      // TODO Deal with a non-null return value
    }
    // If this is a digital write command
    else if (type == "digitalWrite") {
      // Ensure the correct properties
      if (!msg.containsKey("pin") || !msg.containsKey("value")) {
        showReceiveError();
        return;
      }

      // Get the pin to change
      const char * pin = (const char *)msg["pin"];

      // Get the value to change to
      JsonVariant value = msg["value"];

      // Write the pin
      writePin(FATHYM_DIGITAL, pin, value);
    }
    // If this is an analog write command
    else if (type == "analogWrite") {
      // Ensure the correct properties
      if (!msg.containsKey("pin") || !msg.containsKey("value")) {
        showReceiveError();
        return;
      }

      // Get the pin to change
      const char * pin = (const char *)msg["pin"];

      // Get the value to change to
      JsonVariant value = msg["value"];

      // Write the pin
      writePin(FATHYM_ANALOG, pin, value);
    }

    // Show message receive success
    if (FATHYM_LED_STATUS) {
        RGB.control(true);
        RGB.color(0, 255, 0);
        delay(FATHYM_RGB_LED_DELAY);
        RGB.control(false);
    }
  }
}

// Writes to a pin using analog or digital
void Fathym::writePin(uint8_t mode, const char * pin, JsonVariant value) {
  // Convert pin from string to value
  String pinStr = String(pin);
  uint8_t pinNum;

  // Analog pins
  if      (pinStr == "A0") pinNum = A0;
  else if (pinStr == "A1") pinNum = A1;
  else if (pinStr == "A2") pinNum = A2;
  else if (pinStr == "A3") pinNum = A3;
  else if (pinStr == "A4") pinNum = A4;
  else if (pinStr == "A5") pinNum = A5;
  // Digital pins
  else if (pinStr == "D0") pinNum = D0;
  else if (pinStr == "D1") pinNum = D1;
  else if (pinStr == "D2") pinNum = D2;
  else if (pinStr == "D3") pinNum = D3;
  else if (pinStr == "D4") pinNum = D4;
  else if (pinStr == "D5") pinNum = D5;
  else if (pinStr == "D6") pinNum = D6;
  else if (pinStr == "D7") pinNum = D7;

  // Convert pin value
  uint16_t pinValue;

  // From boolean (true=HIGH, false=LOW)
  if (value.is<bool>()) {
    pinValue = (bool)value;
  }
  // Otherwise from number
  else {
    pinValue = (uint16_t)value;
  }

  // Set the pin mode to output if it is not already
  if (getPinMode(pinNum) != OUTPUT) pinMode(pinNum, OUTPUT);

  // Carry out the correct write
  if (mode == FATHYM_ANALOG) {
    analogWrite(pinNum, pinValue);
  }
  else if (mode == FATHYM_DIGITAL) {
    digitalWrite(pinNum, pinValue);
  }
}

// Registers a custom function with Fathym to be called remotely
bool Fathym::registerFunction(const char * name, FathymFunction function) {
  // If we're out of registrations, can't register
  if (_funcIndex > 32 - 1) return false;

  FunctionRegistration ff = _funcRegs[_funcIndex];
  ff.name = String(name);
  ff.func = function;
  _funcRegs[_funcIndex] = ff;
  _funcIndex++;

  return true;
}

// Calls a registered function by name
String Fathym::callRegFunction(String name, String args) {
  // Find the registered function by name
  for (uint8_t i = 0; i < 32; i++) {
    FunctionRegistration ff = _funcRegs[i];
    if (ff.name == "") continue; // no name/key

    // If this is the function matched by name, call it
    if (ff.name == name) {
      return (*ff.func)(args);
    }
  }

  return NULL;
}

// Applies device configuration values from a JSON values object
bool Fathym::applyConfig(JsonObject & values, bool save) {
  JsonObject & config = *_config;

  // Go through each value
  for(JsonObject::iterator it=values.begin(); it!=values.end(); ++it) {
      // Get the current key
      const char * key = (const char *)it->key;

      // Assign local value based on key
      if (strcmp(key, "publishRate") == 0) {
        uint16_t value = (uint16_t)it->value;

        // Reject values of 0 as invalid
        if (value == 0) {
          Serial.println("Invalid publishRate: 0");
        }
        // Otherwise apply it
        else {
          setPublishRate(value);
          config[key] = value;
        }
      }
  }

  // Mark that the device config has changed
  _configChanged = true;

  Serial.println("Device config applied");

  // Save the configuration values to flash
  if (save) {
    char c[FATHYM_CONFIG_BUFFER_SIZE];
    config.printTo(c, FATHYM_CONFIG_BUFFER_SIZE);

    // Define various address offsets for different values of the configuration system
    uint8_t cfLength = strlen(FATHYM_CONFIG_FLAG) + 1;
    uint32_t configLengthAddress = FATHYM_CONFIG_ADDRESS + cfLength;
    uint32_t configJsonAddress = configLengthAddress + 2;

    // First write the length of the config JSON string
    uint16_t configJsonLength = strlen(c) + 1;
    _flash->write(configJsonLength, configLengthAddress);

    // Next write the configuration JSON string
    _flash->writeString(c, configJsonAddress);

    Serial.println("Device config saved");
  }
}

// Flashes the debug LED pin a given number of flashes with a given millisecond delay between high/low
void Fathym::flash(uint8_t numFlashes, uint8_t delayMs) {
  if (!FATHYM_LED_STATUS) return;

  for (int i = 0; i < numFlashes; i++) {
    digitalWrite(FATHYM_STATUS_LED_PIN, HIGH);
    delay(delayMs);
    digitalWrite(FATHYM_STATUS_LED_PIN, LOW);
    delay(delayMs);
  }
}

// Flashes the RGB LED a given number of flahses with a given millisecond delay between on/off
void Fathym::flashRGB(uint8_t numFlashes, uint8_t delayMs, uint8_t r, uint8_t g, uint8_t b) {
  if (!FATHYM_LED_STATUS) return;

  // Take control of the RGB LED
  RGB.control(true);

  for (uint8_t i = 0; i < numFlashes; i++) {
    RGB.color(r, g, b);
    delay(FATHYM_RGB_LED_DELAY);
    RGB.color(0, 0, 0);
    delay(FATHYM_RGB_LED_DELAY);
  }

  // Return control
  RGB.control(false);
}

// Flashes an error state status if the LEDs are configured and enabled
void Fathym::showReceiveError(void) {
  if (!FATHYM_LED_STATUS) return;
  flashRGB(2, FATHYM_RGB_LED_DELAY, 255, 0, 12);
  uint8_t r = 255, g = 0, b = 12;
}

// Remove a value entry from the message
void Fathym::remove(const char * name) {
  JsonObject & json = *_json;
  json.remove(name);
}

// Sets a boolean message value
void Fathym::set(const char * name, bool value) {
  JsonObject & json = *_json;
  json[name] = value;
}

// Sets a string message value
void Fathym::set(const char * name, const char * value) {
  JsonObject & json = *_json;
  json[name] = value;
}

// Sets a float message value
void Fathym::set(const char * name, float value) {
  set(name, value, FATHYM_DEFAULT_DECIMAL_PLACES);
}

// Sets a float message value and determines the number of decimal places to include
void Fathym::set(const char * name, float value, uint8_t decimals) {
  JsonObject & json = *_json;
  json[name].set(value, decimals);
}

// Sets a double message value
void Fathym::set(const char * name, double value) {
  set(name, value, FATHYM_DEFAULT_DECIMAL_PLACES);
}

// Sets a double message value and determines the number of decimal places to include
void Fathym::set(const char * name, double value, uint8_t decimals) {
  JsonObject & json = *_json;
  json[name].set(value, decimals);
}

// Sets an int message value
void Fathym::set(const char * name, int value) {
  JsonObject & json = *_json;
  json[name] = value;
}

// Sets a long message value
void Fathym::set(const char * name, long value) {
  JsonObject & json = *_json;
  json[name] = value;
}

// Sets a float message value with the associated units
void Fathym::set(const char * name, float value, const char * units) {
  set(name, value, units, FATHYM_DEFAULT_DECIMAL_PLACES);
}

// Sets a float message value with the associated units and determines the number of decimal places to include
void Fathym::set(const char * name, float value, const char * units, uint8_t decimals) {
  JsonObject & json = *_json;

  // Get the nested object for the value/units
  JsonObject & nestedObj =  json[name];

  // Create it if it doesn't exist
  if (nestedObj == JsonObject::invalid()) {
    JsonObject & newNested = json.createNestedObject(name);
    newNested["value"].set(value, decimals);
    newNested["units"] = units;
  }
  // Otherwise update the current object
  else {
    nestedObj["value"].set(value, decimals);
    nestedObj["units"] = units;
  }
}

// Sets a double message value with the associated units
void Fathym::set(const char * name, double value, const char * units) {
  set(name, value, units, FATHYM_DEFAULT_DECIMAL_PLACES);
}

// Sets a double message value with the associated unit sand determines the number of decimal places to include
void Fathym::set(const char * name, double value, const char * units, uint8_t decimals) {
  JsonObject & json = *_json;

  // Get the nested object for the value/units
  JsonObject & nestedObj =  json[name];

  // Create it if it doesn't exist
  if (nestedObj == JsonObject::invalid()) {
    JsonObject & newNested = json.createNestedObject(name);
    newNested["value"].set(value, decimals);
    newNested["units"] = units;
  }
  // Otherwise update the current object
  else {
    nestedObj["value"].set(value, decimals);
    nestedObj["units"] = units;
  }
}

// Sets a int message value with the associated units
void Fathym::set(const char * name, int value, const char * units) {
  JsonObject & json = *_json;

  // Get the nested object for the value/units
  JsonObject & nestedObj =  json[name];

  // Create it if it doesn't exist
  if (nestedObj == JsonObject::invalid()) {
    JsonObject & newNested = json.createNestedObject(name);
    newNested["value"] = value;
    newNested["units"] = units;
  }
  // Otherwise update the current object
  else {
    nestedObj["value"] = value;
    nestedObj["units"] = units;
  }
}

// Sets a long message value with the associated units
void Fathym::set(const char * name, long value, const char * units) {
  JsonObject & json = *_json;

  // Get the nested object for the value/units
  JsonObject & nestedObj =  json[name];

  // Create it if it doesn't exist
  if (nestedObj == JsonObject::invalid()) {
    JsonObject & newNested = json.createNestedObject(name);
    newNested["value"] = value;
    newNested["units"] = units;
  }
  // Otherwise update the current object
  else {
    nestedObj["value"] = value;
    nestedObj["units"] = units;
  }
}

// Prints the current fathym JSON data to the serial port for debugging
void Fathym::printJson(void) {
  JsonObject & json = *_json;
  json.printTo(Serial);
  Serial.println();
}
